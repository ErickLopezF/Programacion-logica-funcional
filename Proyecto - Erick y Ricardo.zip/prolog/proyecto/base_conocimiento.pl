:- use_module(library(pce)).

% Definición de plantas y sus propiedades
:- dynamic planta_medicinal/1, propiedad/2, receta/2, trata/2, advertencia/2, metodo_uso/2, iman/2, nombre_cientifico/2, medicamento/2, efectos/2, elementos_contiene/2, origen/2.

% Plantas medicinales
planta_medicinal(cuajilote).
planta_medicinal(cuasia).
planta_medicinal(damiana).
planta_medicinal(pulsatilla).
planta_medicinal(quebracho).
planta_medicinal(quina).
planta_medicinal(regaliz).

% Nombres científicos de las plantas
nombre_cientifico(cuajilote, 'Parmentiera aculeata').
nombre_cientifico(cuasia, 'Quassia amara').
nombre_cientifico(damiana, 'Turnera diffusa').
nombre_cientifico(pulsatilla, 'Anemone pulsatilla').
nombre_cientifico(quebracho, 'Cysiloma auritum').
nombre_cientifico(quina, 'Chinchona calisaya').
nombre_cientifico(regaliz, 'Glycyrriza glabra').

% Elementos contenidos en las plantas
elementos_contiene(cuajilote, [fibra, antioxidantes]).
elementos_contiene(cuasia, [quassina]).
elementos_contiene(damiana, [flavonoides, taninos]).
elementos_contiene(pulsatilla, [febrifuga, sudorifica, expectorante, calmante]).
elementos_contiene(quebracho, [agua, corteza]).
elementos_contiene(quina, [quinina]).
elementos_contiene(regaliz, [orozus, antiinflamatorio]).

% Propiedades de cuajilote
propiedad(cuajilote, estrenimiento_cronico).
propiedad(cuajilote, anasarca).

% Propiedades de cuasia
propiedad(cuasia, diabetes).
propiedad(cuasia, artritis).
propiedad(cuasia, reumatismo).
propiedad(cuasia, dolores_cuerpo).
propiedad(cuasia, migrana).
propiedad(cuasia, dolor_estomago).

% Propiedades de damiana
propiedad(damiana, impotencia_temporal).
propiedad(damiana, diabetes).
propiedad(damiana, nefritis).
propiedad(damiana, cistitis).
propiedad(damiana, problemas_vejiga).

% Propiedades de pulsatilla
propiedad(pulsatilla, herpes).
propiedad(pulsatilla, varices).
propiedad(pulsatilla, venereas).
propiedad(pulsatilla, jaquecas).
propiedad(pulsatilla, neuralgias).

% Propiedades de quebracho
propiedad(quebracho, infecciones_intestinales).
propiedad(quebracho, diarrea).
propiedad(quebracho, flujo).
propiedad(quebracho, afecciones_renal).
propiedad(quebracho, lavado_de_heridas).

% Propiedades de quina
propiedad(quina, malaria).
propiedad(quina, paludismo).
propiedad(quina, fiebre).
propiedad(quina, anemia).
propiedad(quina, asma).
propiedad(quina, colico_nervioso).
propiedad(quina, tetano).
propiedad(quina, epilepsia).
propiedad(quina, ictericia).

% Propiedades de regaliz
propiedad(regaliz, inflamaciones).
propiedad(regaliz, mal_aliento).
propiedad(regaliz, ulceras_duodenales).

% Recetas
receta(cuajilote, hervir_corteza_agua).
receta(cuasia, te_corteza).
receta(damiana, te).
receta(pulsatilla, 'Se debe estar fresco y se recomienda para herpes, rebelde, tos ferina, ulceras varicosas. En quemaduras del sol, ayuda a calmar la irritacion.').
receta(quebracho, 'Poner corteza a hervir para preparar una aguita.').
receta(quina, 'Uso: cocimiento (te) o vino ya preparado de venta en farmacias.').
receta(regaliz, 'Raiz hervida sirve en inflamaciones de boca y encías, laringe. Para mal aliento y dolores de ulcera duodenal.').

% Advertencias
advertencia(cuajilote, gastroenteritis).
advertencia(cuajilote, rectitis).
advertencia(cuajilote, enterocolitis).
advertencia(cuasia, ninguno).
advertencia(damiana, ninguno).
advertencia(pulsatilla, ninguno).
advertencia(quebracho, ninguno).
advertencia(quina, ninguno).
advertencia(regaliz, ninguno).

% Métodos de uso
metodo_uso(cuajilote, hervir_corteza_agua).
metodo_uso(cuasia, te_corteza).
metodo_uso(damiana, te).
metodo_uso(pulsatilla, fresco).
metodo_uso(quebracho, hervir_corteza_agua).
metodo_uso(quina, cocimiento).
metodo_uso(regaliz, raiz_hervida).

% Medicamentos y sus plantas
medicamento(aspirina, asp_salix).
medicamento(digital, digitalis_purpurea).
medicamento(morfina, papaver_somniferum).

% Efectos de los medicamentos
efectos(aspirina, analgesico).
efectos(digital, cardiotonico).
efectos(morfina, analgesico).

% Definición de imágenes de las plantas (asegúrate de que las rutas sean correctas)
iman(cuajilote, 'C:\\prolog\\proyecto\\imagenes\\Cuajilote.jpg').
iman(cuasia, 'C:\\prolog\\proyecto\\imagenes\\Cuasia.jpg').
iman(damiana, 'C:\\prolog\\proyecto\\imagenes\\Damiana.jpg').
iman(pulsatilla, 'C:\\prolog\\proyecto\\imagenes\\Pulsatilla.jpg').
iman(quebracho, 'C:\\prolog\\proyecto\\imagenes\\Quebracho.jpg').
iman(quina, 'C:\\prolog\\proyecto\\imagenes\\Quina.jpg').
iman(regaliz, 'C:\\prolog\\proyecto\\imagenes\\Regaliz.jpg').

% Cultura herbolaria
cultura_herbolario(griegos).
cultura_herbolario(egipcios).
cultura_herbolario(chinos).
cultura_herbolario(aztecas).

% Usos herbolarios
uso_herbolario(griegos, asp_salix).
uso_herbolario(egipcios, aloe).
uso_herbolario(chinos, gingko).
uso_herbolario(aztecas, chocolatl).

% Medicamentos derivados de plantas
derivado_de(aspirina, asp_salix).
derivado_de(digital, digitalis_purpurea).
derivado_de(morfina, papaver_somniferum).

% Reglas adicionales
uso_moderado(P) :- advertencia(P, gastroenteritis); advertencia(P, rectitis); advertencia(P, enterocolitis).
uso_tisana(P) :- metodo_uso(P, te); metodo_uso(P, te_corteza).
importancia_herbolario(Cultura, Planta) :- cultura_herbolario(Cultura), uso_herbolario(Cultura, Planta).
efectos_secundarios(Medicamento) :- derivado_de(Medicamento, Planta), planta_medicinal(Planta), not(uso_herbolario(_, Planta)).
contraste_herbolario_medicina(Planta, Medicamento) :-
    planta_medicinal(Planta), 
    derivado_de(Medicamento, Planta), 
    efectos_secundarios(Medicamento),
    write('La planta '), write(Planta),
    write(' tiene un derivado moderno llamado '), write(Medicamento),
    write(' que puede tener efectos secundarios.').

% Consultas

% ¿Cuáles son plantas o plantas medicinales?
plantas_medicinales(Plantas) :-
    findall(Planta, planta_medicinal(Planta), Plantas).

% ¿Qué elementos se encuentran en las plantas?
elementos_plantas(Elementos) :-
    findall(Elemento, elementos_contiene(_, Elemento), Elementos).

% ¿Qué elementos tiene una planta en específica? Como por ejemplo la manzanilla
elementos_planta(Planta, Elementos) :-
    findall(Elemento, elementos_contiene(Planta, Elemento), Elementos).

% ¿Qué plantas producen medicamentos?
plantas_medicamentos(Plantas) :-
    findall(Planta, derivado_de(_, Planta), Plantas).

% ¿Qué medicamentos produce una planta en específico?
medicamentos_planta(Planta, Medicamentos) :-
    findall(Medicamento, derivado_de(Medicamento, Planta), Medicamentos).

% ¿Qué medicamentos provienen de plantas?
medicamentos_de_plantas(Medicamentos) :-
    findall(Medicamento, derivado_de(Medicamento, _), Medicamentos).

% ¿Cuáles son las acciones o efectos de medicamentos provenientes de plantas?
acciones_medicamentos(MedicamentosEfectos) :-
    findall((Medicamento, Efecto), efectos(Medicamento, Efecto), MedicamentosEfectos).

% ¿Cuáles son los efectos o acciones de un medicamento en específico?
efectos_medicamento(Medicamento, Efectos) :-
    findall(Efecto, efectos(Medicamento, Efecto), Efectos).

% ¿Cuáles son las acciones o efectos que tienen las plantas?
acciones_plantas(PlantasEfectos) :-
    findall((Planta, Efecto), propiedad(Planta, Efecto), PlantasEfectos).

% Listado de plantas y sus acciones o efectos sobre el organismo
plantas_acciones(Lista) :-
    findall((Planta, Efecto), propiedad(Planta, Efecto), Lista).

% ¿Acciones o efectos de una planta en específico?
acciones_planta(Planta, Acciones) :-
    findall(Accion, propiedad(Planta, Accion), Acciones).

% ¿Qué plantas son analgésicas?
plantas_analgesicas(Plantas) :-
    findall(Planta, (propiedad(Planta, analgesico) ; efectos(_, analgesico)), Plantas).

% Listar plantas medicinales y su nombre científico
listar_plantas_cientifico(Lista) :-
    findall((Planta, NombreCientifico), nombre_cientifico(Planta, NombreCientifico), Lista).

% ¿Cuáles son las enfermedades que curan las plantas?
enfermedades_curadas_por_plantas(Enfermedades) :-
    findall(Enfermedad, trata(_, Enfermedad), Enfermedades).

% ¿Cuáles son las enfermedades que cura una planta en específico?
enfermedades_planta(Planta, Enfermedades) :-
    findall(Enfermedad, trata(Planta, Enfermedad), Enfermedades).

% ¿Cuáles son las plantas que curan una enfermedad como por ejemplo el herpes?
plantas_que_curan_enfermedad(Enfermedad, Plantas) :-
    findall(Planta, trata(Planta, Enfermedad), Plantas).

% ¿Cuáles son las formas de preparación para tratamiento de enfermedades con uso de plantas?
preparacion_plantas(Preparaciones) :-
    findall(Preparacion, receta(_, Preparacion), Preparaciones).

% ¿Cuáles son los modos de preparación de una planta en específico?
preparacion_planta(Planta, Preparaciones) :-
    findall(Preparacion, receta(Planta, Preparacion), Preparaciones).

% ¿Cuál es el tratamiento y su preparación para alguna enfermedad?
tratamiento_enfermedad(Enfermedad, Tratamientos) :-
    findall((Planta, Preparacion), (trata(Planta, Enfermedad), receta(Planta, Preparacion)), Tratamientos).

% ¿Cuáles son los orígenes de las plantas medicinales?
origenes_plantas(Orígenes) :-
    findall(Origen, origen(_, Origen), Orígenes).

% ¿Cuál es el origen de una planta?
origen_planta(Planta, Origen) :-
    findall(Origen, origen(Planta, Origen), Origen).

% ¿Cuál es el tratamiento para una enfermedad (ya sea con plantas o medicamentos)?
tratamiento_enfermedad_general(Enfermedad, Tratamientos) :-
    findall((Planta, Preparacion), (trata(Planta, Enfermedad), receta(Planta, Preparacion)), TratamientosPlantas),
    findall((Medicamento, Efecto), (efectos(Medicamento, Efecto), member(Enfermedad, Efecto)), TratamientosMedicamentos),
    append(TratamientosPlantas, TratamientosMedicamentos, Tratamientos).

% Botiquín de plantas
botiquin_de_plantas(Botiquin) :-
    findall((Planta, Enfermedad, Preparacion), (planta_medicinal(Planta), trata(Planta, Enfermedad), receta(Planta, Preparacion)), Botiquin).

% Mostrar imagen
mostrar(V, D, X, Y) :-
    ( exists_file(V) ->
        new(I, image(V)),
        new(B, bitmap(I)),
        send(B, name, image_bitmap),
        new(F2, figure),
        send(F2, display, B),
        new(D1, device),
        send(D1, display, F2),
        send(D, display, D1, point(X, Y))
    ; true ).

% Diálogo para preguntar el nombre de una planta
:- pce_global(@name_prompter, make_name_prompter).

make_name_prompter(P) :-
    new(P, dialog),
    send(P, kind, transient),
    send(P, append, label(prompt)),
    send(P, append, new(TI, text_item(name, '', message(P?ok_member, execute)))),
    send(P, append, button(ok, message(P, return, TI?selection))),
    send(P, append, button(cancel, message(P, return, @nil))).

ask_name(Prompt, Label, Name) :-
    send(@name_prompter?prompt_member, selection, Prompt),
    send(@name_prompter?name_member, label, Label),
    send(@name_prompter?name_member, clear),
    get(@name_prompter, confirm_centered, RawName),
    send(@name_prompter, show, @off),
    RawName \== @nil,
    Name = RawName.

ask_name :-
    ask_name('Ingrese el nombre de una planta', 'Planta:', Planta),
    pp(Planta).

% Diálogo para preguntar una consulta
:- pce_global(@consulta_prompter, make_consulta_prompter).

make_consulta_prompter(P) :-
    new(P, dialog),
    send(P, kind, transient),
    send(P, append, label(prompt)),
    send(P, append, new(TI, text_item(name, '', message(P?ok_member, execute)))),
    send(P, append, button(ok, message(P, return, TI?selection))),
    send(P, append, button(cancel, message(P, return, @nil))).

ask_consulta(Prompt, Label, Consulta) :-
    send(@consulta_prompter?prompt_member, selection, Prompt),
    send(@consulta_prompter?name_member, label, Label),
    send(@consulta_prompter?name_member, clear),
    get(@consulta_prompter, confirm_centered, RawConsulta),
    send(@consulta_prompter, show, @off),
    RawConsulta \== @nil,
    Consulta = RawConsulta.

ask_consulta :-
    ask_consulta('Ingrese su consulta', 'Consulta:', Consulta),
    ejecutar_consulta(Consulta).

ejecutar_consulta(Consulta) :-
    catch(atom_to_term(Consulta, Term, _), _, fail),
    ( call(Term) ->
        format(atom(Resultado), '~w', [Term]),
        mostrar_resultado(Resultado)
    ; mostrar_resultado('Consulta no válida o no se encontró información.')
    ).

mostrar_resultado(Resultado) :-
    new(D, dialog('Resultado de la Consulta')),
    send(D, append, text(Resultado)),
    send(D, open_centered).

start :-
    new(D, dialog('Sistema de Consultas sobre Plantas Medicinales')),
    send(D, size, size(800, 600)),
    send(D, append, new(Menu, menu_bar)),
    send(Menu, append, new(Iniciar, popup(iniciar))),
    send_list(Iniciar, append,
              [menu_item('Buscar planta', message(@prolog, ask_name)),
               menu_item('Realizar consulta', message(@prolog, ask_consulta))]),
    send(D, open, point(0, 0)).

% Mostrar información de la planta seleccionada
pp(Planta) :-
    planta_medicinal(Planta),
    new(D, dialog(Planta)),
    send(D, size, size(800, 600)),
    send(D, append, new(Menu, menu_bar)),
    send(D, display, text(Planta, center, bold), point(400, 5)),

    send(D, display, text('Propiedades:', left, normal), point(10, 50)),
    propiedades_planta(Planta, Propiedades),
    mostrar_lista(Propiedades, D, 70),

    (receta(Planta, Receta) ->
        send(D, display, text('Receta:', left, normal), point(10, 200)),
        send(D, display, text(Receta, left, normal), point(10, 220))
    ; true),

    ( iman(Planta, Foto) ->
        mostrar(Foto, D, 400, 50)
    ; true),

    send(D, open, point(200, 200)).

% Mostrar lista de propiedades
mostrar_lista([], _, _).
mostrar_lista([H|T], D, Y) :-
    send(D, display, text(H, left, normal), point(10, Y)),
    Y1 is Y + 20,
    mostrar_lista(T, D, Y1).

propiedades_planta(Planta, Propiedades) :-
    findall(Propiedad, propiedad(Planta, Propiedad), Propiedades).

:- start.
