import Data.Char (toUpper)

type Materia = String
type Puntuacion = Int
type Evaluacion = String
type Historial = [(Materia, Puntuacion)]

calificar :: Puntuacion -> Evaluacion
calificar puntuacion
    | puntuacion >= 95 = "Excelente"
    | puntuacion >= 85 = "Notable"
    | puntuacion >= 75 = "Bueno"
    | puntuacion >= 70 = "Suficiente"
    | otherwise = "Insuficiente"

evaluarHistorial :: Historial -> [(Materia, Evaluacion)]
evaluarHistorial historial = map (\(materia, puntuacion) -> (ponerMayuscula materia, calificar puntuacion)) historial
  where ponerMayuscula = map toUpper

main :: IO ()
main = do
    let historial = [("Calculo", 70), ("Prog. Web", 80), ("Fisica", 77), ("Quimica", 100)]
    putStrLn "Historial original:"
    print historial
    putStrLn "Historial evaluado con materias en mayúsculas y calificaciones:"
    print (evaluarHistorial historial)
