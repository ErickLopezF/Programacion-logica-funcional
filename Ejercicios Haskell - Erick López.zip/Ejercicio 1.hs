type Monto = Float
type Tasa = Float
type Artículo = (Monto, Tasa)
type Canasta = [Artículo]

-- Función que aplica una modificación al precio basada en una tasa.
modificarPrecio :: Monto -> Tasa -> Monto
modificarPrecio monto tasa = monto * (1 + tasa / 100)

-- Función para procesar los artículos de la canasta aplicando una modificación al precio.
procesarCanasta :: Canasta -> (Monto -> Tasa -> Monto) -> Monto
procesarCanasta canasta funcionModificadora = foldr (+) 0 (map (\(monto, tasa) -> funcionModificadora monto tasa) canasta)

main :: IO ()
main = do
    let canastaDescuento = [(100, -10), (200, -20)] -- Negativo para descuentos
    let canastaIVA = [(100, 21), (200, 21)]
    
    putStrLn $ "Precio total con descuentos: " ++ show (procesarCanasta canastaDescuento modificarPrecio)
    putStrLn $ "Precio total con IVA: " ++ show (procesarCanasta canastaIVA modificarPrecio)
