transformarElementos :: (a -> b) -> [a] -> [b]
transformarElementos f lista = map f lista

doblar :: Int -> Int
doblar x = x * 2

alCuadrado :: Int -> Int
alCuadrado x = x ^ 2

main :: IO ()
main = do
    let numeros = [11, 42, 23, 54, 15]
    putStrLn "Lista original:"
    print numeros
    
    let numerosDoblados = transformarElementos doblar numeros
    putStrLn "Lista después de doblar cada elemento:"
    print numerosDoblados
    
    let numerosAlCuadrado = transformarElementos alCuadrado numeros
    putStrLn "Lista después de calcular el cuadrado de cada elemento:"
    print numerosAlCuadrado
