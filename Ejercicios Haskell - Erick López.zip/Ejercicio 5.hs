import Prelude

type Vector2 = (Float, Float)
type Vector3 = (Float, Float, Float)

longitudVector2 :: Vector2 -> Float
longitudVector2 (x, y) = sqrt (x ** 2 + y ** 2)

longitudVector3 :: Vector3 -> Float
longitudVector3 (x, y, z) = sqrt (x ** 2 + y ** 2 + z ** 2)

main :: IO ()
main = do
    let vector2 = (6, 9)
    putStrLn $ "La longitud del vector 2D " ++ show vector2 ++ " es " ++ show (longitudVector2 vector2)

    let vector3 = (3, 5, 8)
    putStrLn $ "La longitud del vector 3D " ++ show vector3 ++ " es " ++ show (longitudVector3 vector3)
