import Data.List (nub)
import Data.Char (isSpace, isPunctuation, toLower)

eliminarPuntuacion :: String -> String
eliminarPuntuacion = filter (\caracter -> not (isPunctuation caracter) || caracter == '\'')

aMinusculas :: String -> String
aMinusculas = map toLower

separarPalabras :: String -> [String]
separarPalabras = words . eliminarPuntuacion . aMinusculas

palabrasConLongitud :: String -> [(String, Int)]
palabrasConLongitud texto = map (\palabra -> (palabra, length palabra)) . nub $ separarPalabras texto

main :: IO ()
main = do
    let texto = "Hola me llamo Erick"
    putStrLn "Texto original:"
    putStrLn texto
    putStrLn "Diccionario de palabras y sus longitudes:"
    print (palabrasConLongitud texto)
