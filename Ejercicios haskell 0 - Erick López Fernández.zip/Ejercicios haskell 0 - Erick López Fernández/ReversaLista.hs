reversoLista :: [a] -> [a]
reversoLista [] = []
reversoLista (x:xs) = reversoLista xs ++ [x]

main :: IO ()
main = do
    putStrLn "Introduce una lista de enteros separados por espacios: "
    input <- getLine
    let lista = map read $ words input :: [Int]
    print (reversoLista lista)
