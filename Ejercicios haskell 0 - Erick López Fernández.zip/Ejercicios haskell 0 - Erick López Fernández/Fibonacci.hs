fibonacci :: Int -> Int
fibonacci 0 = 0
fibonacci 1 = 1
fibonacci n = fibonacci (n - 1) + fibonacci (n - 2)

main :: IO ()
main = do
    putStrLn "Introduce el índice n para obtener el n-ésimo número de Fibonacci: "
    input <- getLine
    let indice = read input :: Int
    putStrLn ("El " ++ show indice ++ "-ésimo número de Fibonacci es: " ++ show (fibonacci indice))
