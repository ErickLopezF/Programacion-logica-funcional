longitudCadena :: String -> Int
longitudCadena cadena = length cadena

main :: IO ()
main = do
    putStrLn "Introduce una cadena: "
    cadena <- getLine
    putStrLn ("La longitud de la cadena es: " ++ show (longitudCadena cadena))
