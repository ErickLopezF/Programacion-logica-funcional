sumarLista :: [Int] -> Int
sumarLista [] = 0 
sumarLista (x:xs) = x + sumarLista xs 

main :: IO ()
main = do

    let lista1 = [1, 2, 3, 4, 5]
    let lista2 = [10, 20, 30]
    let lista3 = []

    print (sumarLista lista1) -- Debería mostrar 15
    print (sumarLista lista2) -- Debería mostrar 60
    print (sumarLista lista3) -- Debería mostrar 0
