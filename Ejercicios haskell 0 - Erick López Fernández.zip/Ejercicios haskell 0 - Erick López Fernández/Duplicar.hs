duplicarElementos :: [Int] -> [Int]
duplicarElementos lista = map (*2) lista

main :: IO ()
main = do
    putStrLn "Introduce una lista de enteros separados por espacio: "
    input <- getLine
    let numeros = map read $ words input :: [Int]
    putStrLn "Lista con elementos duplicados: "
    print (duplicarElementos numeros)
