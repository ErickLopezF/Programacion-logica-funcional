factorial :: Int -> Int
factorial 0 = 1
factorial n = n * factorial (n - 1)

main :: IO ()
main = do
  putStrLn "Ingrese un número para calcular su factorial: "
  n <- readLn 
  putStrLn ("El factorial de " ++ show n ++ " es: " ++ show (factorial n))
