filtrarPares :: [Int] -> [Int]
filtrarPares lista = [x | x <- lista, x `mod` 2 == 0]

main :: IO ()
main = do
    putStrLn "Introduce una lista de enteros separados por espacio: "
    input <- getLine
    let numeros = map read $ words input :: [Int]
    putStrLn "Lista filtrada con solo elementos pares: "
    print (filtrarPares numeros)
